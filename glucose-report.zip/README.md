# Glucose CSV Analyzer
Disclaimer

This repository is provided for educational and experimental purposes only.
It is NOT intended for medical use, diagnosis, treatment, or clinical decision-making.

The author makes no guarantees regarding the accuracy, completeness, or suitability
of the code or its outputs. Use of this repository is entirely at your own risk.

The author shall not be held liable for any damages, losses, or consequences
arising from the use of this code.

# Glucose CSV Analyzer (Learning Project)

## Overview
This project extracts abnormal glucose values from a CSV file
and exports results as JSON for analysis and validation purposes.

## Requirements
- Python 3.10+
- pandas

## Usage
```bash
python main.py --csv data/input.csv --out out --high 150 --low 70


免責事項（Disclaimer）

本リポジトリに含まれるコードおよび生成物は、学習・検証目的で作成されたものであり、
医療行為、診断、治療、またはそれらの代替を意図するものではありません。

本コードは入力データの正確性、完全性、最新性を保証しません。
本リポジトリの利用により生じたいかなる直接的・間接的損害についても、
作者は一切の責任を負いません。

本コードを実運用（業務・医療・安全判断等）に使用する場合は、
必ず利用者自身の責任において十分な検証・確認を行ってください。



CSVファイルから日付と血糖値を読み込み、
指定した閾値を超える異常値を抽出し、
JSON形式で出力する小さな分析プログラムです。

---

## 機能

- CSV読み込み（date, glucose 列）
- 高血糖・低血糖の抽出
- 異常データを JSON に保存
- 閾値をコマンドライン引数で指定可能

---

## 動作環境

- Python 3.10+
- pandas

---

## セットアップ

```bash
pip install -r requirements.txt

