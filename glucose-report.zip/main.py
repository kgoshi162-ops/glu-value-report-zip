from pathlib import Path
import argparse
import json
import pandas as pd
import sys


# ===== CSV 読み込み =====
def load_csv(csv_path: Path) -> pd.DataFrame:
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    df = pd.read_csv(csv_path)

    required = {"date", "glucose"}
    if not required.issubset(df.columns):
        raise KeyError(f"Missing required columns: {sorted(required - set(df.columns))}")

    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    return df


# ===== 異常値抽出 =====
def extract_alerts(df: pd.DataFrame, high_th: int, low_th: int):
    high = df[df["glucose"] > high_th]
    low = df[df["glucose"] < low_th]

    print("\n=== Alerts ===")
    print(f"High (>{high_th}): {len(high)}")
    if len(high):
        print(high[["date", "glucose"]].to_string(index=False))

    print(f"Low  (<{low_th}): {len(low)}")
    if len(low):
        print(low[["date", "glucose"]])

    if len(high) == 0 and len(low) == 0:
        print("No alerts detected")

    return high, low

def summaraize_by_day(df : pd.dataFrame) :
    d = df.copy()
    d["date"] = pd .to_datetime(d["date"])

    daily = (
        d.groupby(d["date"].dt.date)
        ["glucose"]
        .agg(avg="mean", max = "max", min = "min", count="count")
        .reset_index()
    )  
    daily["date"]  = pd.to_datetime(daily["date"])
    daily["avg"] = daily["avg"].round(1)
    return daily

# ===== JSON 出力 =====
def export_alerts_json(high, low, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)

    h = high.copy()
    l = low.copy()

    if "date" in h.columns:
        h["date"] = h["date"].dt.strftime("%Y-%m-%d")
    if "date" in l.columns:
        l["date"] = l["date"].dt.strftime("%Y-%m-%d")

    data = {
        "high": h.to_dict(orient="records"),
        "low": l.to_dict(orient="records"),
    }

    out_path = out_dir / "alerts.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print("\n=== Alerts JSON Exported ===")
    print(out_path.resolve())
def export_abnormal_days(df: pd.DataFrame, out_dir: Path):
    alerts_path = out_dir / "alerts.json"
    alerts = json.loads(alerts_path.read_text(encoding="utf-8"))

    # get("high", []): keyが無ければ空リスト
    abnormal_list = alerts.get("high", []) + alerts.get("low", [])

    out_path = out_dir / "abnormal_days.csv"

    # abnormal_list が空なら「空のCSV」ではなく「ファイルを作らず終了」
    if len(abnormal_list) == 0:
        print("\n=== Abnormal Days ===")
        print("No abnormal days detected.")
        return

    abnormal = pd.DataFrame(abnormal_list)
    abnormal["date"] = pd.to_datetime(abnormal["date"])

    # 日別集計（dateごとに avg/max/min/count）
    daily = (
        df.groupby(df["date"].dt.date)["glucose"]
          .agg(avg="mean", max="max", min="min", count="count")
          .reset_index()
    )
    daily["date"] = pd.to_datetime(daily["date"])

    # merge: dateが一致する行だけ残す
    result = daily.merge(abnormal[["date"]], on="date", how="inner")

    result.to_csv(out_path, index=False)

    print("\n=== Abnormal Days Exported ===")
    print(out_path.resolve())


# ===== このブロックの役割：週次異常CSV（out/abnormal_weeks.csv）を作る =====
# out_dir: 出力フォルダ（out）
# "abnormal_days.csv" を読んで、週単位に avg/max/min/days を集計して書き出す
def export_abnormal_weeks(out_dir: Path):
    # days_csv: out/abnormal_days.csv のパス（Path型）
    days_csv = out_dir / "abnormal_days.csv"

    # exists(): ファイルが存在するか（True/False）
    if not days_csv.exists():
        return

    df = pd.read_csv(days_csv)

    # empty: DataFrameが0行か（True/False）
    if df.empty:
        return

    # "date": 文字列→日時型（週の計算に必要）
    df["date"] = pd.to_datetime(df["date"])

    # to_period("W"): 日付→週（例: 2026-01-12/2026-01-18）
    df["week"] = df["date"].dt.to_period("W").astype(str)

    weekly = (
        df.groupby("week")
          .agg(avg=("avg", "mean"), max=("max", "max"), min=("min", "min"), days=("date", "count"))
          .reset_index()
    )
    weekly["avg"] = weekly["avg"].round(1)

    out_path = out_dir / "abnormal_weeks.csv"
    # index=False: 左端の行番号をCSVに出さない
    weekly.to_csv(out_path, index=False)


# ===== 最終レポート =====
def export_final_report(high_th: int, low_th: int, out_dir: Path):
    alerts_path = out_dir / "alerts.json"
    alerts = json.loads(alerts_path.read_text(encoding="utf-8"))
    
    weeks_csv = out_dir / "abnormal_weeks.csv"
    if weeks_csv.exists() and weeks_csv.stat().st_size > 0 :
        wdf = pd.read_csv(weeks_csv)
        weeks = wdf.to_dict(orient="records")
    else :
        weeks = []


    
    report = {
        "thresholds": {
            "high": high_th,
            "low": low_th,
        },
        "weeks": weeks
    }

    out_path = out_dir / "final_report.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print("\n=== Final Report Exported ===")
    print(out_path.resolve())


# ===== CLI =====
def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default="data/input.csv")
    p.add_argument("--out", default="out")
    p.add_argument("--high", type=int, default=150)
    p.add_argument("--low", type=int, default=70)
    return p.parse_args()


def main():
    args = parse_args()

    base = Path(__file__).parent
    csv_path = base / args.csv
    out_dir = base / args.out

    df = load_csv(csv_path)
    high, low = extract_alerts(df, args.high, args.low)
    export_alerts_json(high, low, out_dir)
    export_abnormal_days(df, out_dir)      # 既にある想定（無ければあなたの関数呼び出しに合わせる）
    export_abnormal_weeks(out_dir)         # ← これを追加
    export_final_report(args.high, args.low, out_dir)



if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)
